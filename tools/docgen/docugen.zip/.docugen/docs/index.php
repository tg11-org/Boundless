<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Python API Docs</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="with-sidebar" data-theme="dark">
  <?php include("api/sidebar.php"); ?>
  <div class="theme-switcher">
    <label for="theme">Theme:</label>
    <select id="theme" onchange="changeTheme(this.value)">
      <!-- Dark Themes -->
      <option value="dark">Dark</option>
      <option value="midnight">Midnight</option>
      <option value="terminal">Terminal</option>
      <option value="sunset">Sunset</option>
      <option value="cyberpunk">Cyberpunk</option>
      <option value="neonorange">Neon Orange</option>
      <option value="dracula">Dracula</option>
      <option value="nightsky">Night Sky</option>
      <option value="monokai">Monokai</option>
      <option value="grape">Grape Soda</option>
      <option value="deepwine">Deep Wine</option>
      <option value="forest">Dark Forest</option>
      <option value="quantum">Quantum</option>
      <option value="noir">Noir</option>
      <option value="ember">Ember</option>
      <option value="crystal">Dark Crystal</option>
      <option value="obsidian">Obsidian</option>
      <option value="carbon">Carbon</option>
      <option value="dim">Dim</option>
      <option value="vintage">Vintage</option>
      <option value="onyx">Onyx</option>
      <option value="raven">Raven</option>
      <option value="gothic">Gothic</option>
      <option value="slate">Slate</option>
      <option value="nightshade">Nightshade</option>
      <option value="charcoal">Charcoal</option>
      <option value="abyss">Abyss</option>
      <option value="bloodmoon">Bloodmoon</option>
      <option value="ash">Ash</option>
      <option value="cobalt">Cobalt</option>
      <option value="smoke">Smoke</option>
      <option value="amethyst">Amethyst</option>
      <option value="vaporwave">Vaporwave</option>
      <option value="nightdrive">Nightdrive</option>
      <option value="darkrose">Darkrose</option>
      <option value="iron">Iron</option>
      <option value="nebula">Nebula</option>
      <option value="midgray">Midgray</option>
      <option value="midforest">Midforest</option>
      <option value="storm">Storm</option>
      <option value="coal">Coal</option>
      <option value="tar">Tar</option>
      <option value="blackout">Blackout</option>
      <option value="graphite">Graphite</option>
      <!-- Light Themes -->
      <option value="light">Light</option>
      <option value="lavender">Lavender</option>
      <option value="pastel">Pastel</option>
      <option value="ocean">Ocean</option>
      <option value="ivory">Ivory</option>
      <option value="linen">Linen</option>
      <option value="sand">Sand</option>
      <option value="sky">Sky</option>
      <option value="mint">Mint</option>
      <option value="cloud">Cloud</option>
      <option value="peach">Peach</option>
      <option value="rose">Rose</option>
      <option value="butter">Butter</option>
      <option value="fog">Fog</option>
    </select>

  </div>
  <h1>Python API Documentation</h1>
  <?php
    $groups = [];
    foreach (glob("api/*.php") as $file) {
        $base = basename($file);

        // Skip any file that starts with "index" or "sidebar"
        if (preg_match('/^(index|sidebar)/i', $base)) {
            continue;
        }

        $parts = explode(".", $base);
        $group = $parts[0];
        if (!isset($groups[$group])) $groups[$group] = [];
        $groups[$group][] = $file;
    }
    foreach ($groups as $group => $files) {
        echo "<details><summary>$group</summary>";
        foreach ($files as $f) include($f);
        echo "</details>";
    }
  ?>
<script>
function changeTheme(theme) {
  document.body.dataset.theme = theme;
  localStorage.setItem("theme", theme);
}
window.addEventListener("load", () => {
  const savedTheme = localStorage.getItem("theme");
  if (savedTheme) {
    document.body.dataset.theme = savedTheme;
    document.getElementById("theme").value = savedTheme;
  }

  // === Auto-expand details based on anchor ===
  const hash = window.location.hash.substring(1);
  if (hash) {
    const anchor = document.getElementById(hash);
    if (anchor) {
      // Expand parent <details> if collapsed
      let parent = anchor.closest("details");
      if (parent) {
        parent.open = true;
      }

      // Scroll into view with some spacing
      setTimeout(() => {
        anchor.scrollIntoView({ behavior: "smooth", block: "center" });
      }, 200);
    }
  }

  // Expand on sidebar link click
  document.querySelectorAll('#sidebar a[href^="#"]').forEach(link => {
    link.addEventListener("click", (e) => {
      const id = link.getAttribute("href").substring(1);
      const anchor = document.getElementById(id);
      if (anchor) {
        const parent = anchor.closest("details");
        if (parent) parent.open = true;
      }
    });
  });
});

window.addEventListener("DOMContentLoaded", () => {
  const savedTheme = localStorage.getItem("theme");
  if (savedTheme) {
    document.body.dataset.theme = savedTheme;
    const themeSelect = document.getElementById("theme");
    if (themeSelect) themeSelect.value = savedTheme;
  }

  // === Enable sidebar clicks to flash + expand ===
  document.querySelectorAll('#sidebar a[href^="#"]').forEach(link => {
    link.addEventListener("click", e => {
      e.preventDefault();
      const id = decodeURIComponent(link.getAttribute("href").substring(1));
      const target = document.getElementById(id);
      if (target) {
        // Expand parent <details> if any
        const parentDetails = target.closest("details");
        if (parentDetails) parentDetails.open = true;

        // Scroll to and flash
        target.scrollIntoView({ behavior: "smooth", block: "center" });
        target.classList.add("anchor-flash");
        setTimeout(() => target.classList.remove("anchor-flash"), 1000);
        history.pushState(null, "", "#" + id);
      }
    });
  });
});
</script>
</body>
</html>
